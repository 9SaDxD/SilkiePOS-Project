import React, { useState } from 'react';
import axios from 'axios';
import './LoginPage.css';

// --- 👇 (แก้ไข) อัปเดต URL ให้ตรงกับ Port ที่เราบังคับไว้ ---
const APP_URLS = {
    Admin: 'http://localhost:5176',         // (ไปที่ Admin App)
    Staff: 'http://localhost:5174',         // (ไปที่ Staff App)
    Kitchen_Ramen: 'http://localhost:5175', // (ไปที่ Kitchen App)
    Kitchen_Fry: 'http://localhost:5175'    // (ไปที่ Kitchen App)
};

function LoginPage() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleLogin = async (e) => {
        e.preventDefault();
        setError('');
        if (!username || !password) {
            setError('กรุณากรอกข้อมูล');
            return;
        }

        try {
            const response = await axios.post('http://localhost:3000/api/auth/login', {
                username,
                password,
            });
            
            const { token, user } = response.data;

            localStorage.setItem('token', token);
            localStorage.setItem('userRole', user.role);
            localStorage.setItem('username', user.username);

            const targetAppUrl = APP_URLS[user.role];

            if (targetAppUrl) {
                // ส่งตัวไปที่แอปที่ถูกต้อง
                window.location.replace(targetAppUrl);
            } else {
                setError('ไม่พบ Role ที่ถูกต้อง หรือไม่ได้รับอนุญาต');
                localStorage.clear();
            }

        } catch (err) {
            console.error('Login error:', err.response?.data || err.message);
            setError(err.response?.data?.message || 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง');
            localStorage.clear();
        }
    };

    return (
        <div className="login-container">
            <div className="login-card">
                <div className="login-logo">
                    <img src="/images/logo.png" alt="Silkie Chick Ramen Logo" />
                </div>
                <h2>Sign in</h2>
                <form onSubmit={handleLogin} className="login-form">
                    {/* ... (โค้ด input เหมือนเดิม) ... */}
                    <div className="form-group">
                        <input
                            type="text"
                            placeholder="username"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <input
                            type="password"
                            placeholder="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                        />
                    </div>
                    {error && <p className="login-error">{error}</p>}
                    <button type="submit" className="login-button">
                        เข้าสู่ระบบ
                    </button>
                </form>
            </div>
        </div>
    );
}

export default LoginPage;